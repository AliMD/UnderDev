<?php include 'inc/header.php'; ?>
<div class="container">

	<?php include 'inc/logo.php'; ?>
	
</div>
<?php include 'inc/slideshow.php'; ?>
<?php include 'inc/footer.php'; ?>