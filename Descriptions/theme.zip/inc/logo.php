<?php 
	dynamic_content('logo','<img class="logo" ',' />');