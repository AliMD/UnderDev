	<?php dynamic_content('description_title',"<h1 class='title'>",'</h1>') ?>
	
	<?php dynamic_content('description_text',"<p class='desc'>",'</p>') ?>