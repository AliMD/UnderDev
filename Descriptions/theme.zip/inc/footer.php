</section>
<footer>
	<?php dynamic_content('footer_text_left',"<h1>",'</h1>') ?>
	<?php dynamic_content('footer_text_right',"<h2>",'</h2>') ?>
</footer>
</body>
</html>