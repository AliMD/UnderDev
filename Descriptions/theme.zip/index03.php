<?php include 'inc/header.php'; ?>
<?php include 'inc/slideshow.php'; ?>
<div class="container">
	<?php include 'inc/description.php'; ?>
	<?php include 'inc/logo.php'; ?>
	
</div>

<?php include 'inc/footer.php'; ?>